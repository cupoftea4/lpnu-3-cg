import { ColorIcon } from "../../components/ColorIcon";
import { SettingsCards } from "../../components/SettingsCards";
import { DownloadIcon1 } from "../../icons/DownloadIcon1";
import { LeftPanel } from "../../icons/LeftPanel";
import { TopRightPanel } from "../../components/TopRightPanel";
import "./style.css";

export const DarkFractals = (): JSX.Element => {
  return (
    <div className="dark-fractals">
      <LeftPanel className="left-panel" page="fractals" />
      <div className="container">
        <div className="content">
          <div className="top-panel">
            <div className="text-wrapper-2">
              Educational platform - Fractals
            </div>
            <TopRightPanel className="top-right-panel" theme="dark" />
          </div>
          <div className="page">
            <div className="preview">
              <div className="text-wrapper-3">Newton Fractal</div>
              <div className="fractal-frame">
                <img
                  className="img"
                  alt="Rectangle"
                  src="https://c.animaapp.com/TKIJX4bZ/img/rectangle-3.png"
                />
                <img
                  className="zoom"
                  alt="Zoom"
                  src="https://c.animaapp.com/TKIJX4bZ/img/zoom.svg"
                />
              </div>
            </div>
            <div className="right-panel">
              <SettingsCards
                chevronRight2StyleOverrideClassName="design-component-instance-node"
                className="settings-cards-instance"
                color="blue"
                someTextText="Choose function"
              />
              <SettingsCards
                chevronRight2StyleOverrideClassName="settings-cards-2"
                className="settings-cards-instance"
                color="orange"
                icon={<ColorIcon className="color-icon-instance" />}
                someTextText="Choose color"
              />
              <SettingsCards
                chevronRight2StyleOverrideClassName="settings-cards-2"
                className="settings-cards-4"
                color="green"
                icon={<DownloadIcon1 className="download-icon" />}
                showChevronRight={false}
                someTextDivClassName="settings-cards-3"
                someTextText="Download Image"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
