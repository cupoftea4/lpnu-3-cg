export { FunctionIcon4 } from "./FunctionIcon4";
