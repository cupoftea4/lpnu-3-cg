export { AdjustIcon1 } from "./AdjustIcon1";
