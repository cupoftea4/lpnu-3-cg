export { ChevronRight2 } from "./ChevronRight2";
