export { FunctionIcon1 } from "./FunctionIcon1";
