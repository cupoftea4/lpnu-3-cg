export { FunctionIcon2 } from "./FunctionIcon2";
