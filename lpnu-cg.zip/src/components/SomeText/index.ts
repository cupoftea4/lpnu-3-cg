export { SomeText } from "./SomeText";
