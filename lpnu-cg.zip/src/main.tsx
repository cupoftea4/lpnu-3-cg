import React from 'react'
import ReactDOM from 'react-dom/client'
import FractalCanvas from './FractalCanvas.tsx'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <FractalCanvas />
  </React.StrictMode>,
)
